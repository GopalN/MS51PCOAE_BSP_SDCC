extern unsigned char  SPTEMP;

void SPROM_CODE (void);