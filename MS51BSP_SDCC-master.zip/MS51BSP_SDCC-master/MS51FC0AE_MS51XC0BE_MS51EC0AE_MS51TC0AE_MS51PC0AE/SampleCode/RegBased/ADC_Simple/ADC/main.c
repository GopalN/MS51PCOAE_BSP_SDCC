/*
 */

#include <mcs51/8051.h>

void main(void)
{

    // Insert code

    while(1)
        ;

}
