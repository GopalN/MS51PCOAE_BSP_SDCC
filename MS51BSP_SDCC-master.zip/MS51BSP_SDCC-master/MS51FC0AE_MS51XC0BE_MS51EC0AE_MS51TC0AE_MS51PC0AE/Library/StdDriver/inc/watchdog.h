void Enable_WDT_Reset_Config(void);
void Disable_WDT_Reset_Config(void);